VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.MDIForm MDIForm1 
   BackColor       =   &H00808080&
   Caption         =   "Ultimate Cracking Utility v1.0.0"
   ClientHeight    =   5475
   ClientLeft      =   165
   ClientTop       =   555
   ClientWidth     =   7200
   Icon            =   "main.frx":0000
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   3  'Windows Default
   Begin MSComctlLib.ImageList ImageList1 
      Left            =   7200
      Top             =   0
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   9
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0442
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0554
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0666
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0778
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":088A
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":099C
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0AAE
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0BC0
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "main.frx":0CD2
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   360
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   7200
      _ExtentX        =   12700
      _ExtentY        =   635
      ButtonWidth     =   609
      ButtonHeight    =   582
      Wrappable       =   0   'False
      Appearance      =   1
      Style           =   1
      ImageList       =   "ImageList1"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   7
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "cracker"
            Object.ToolTipText     =   "Password Cracker"
            ImageIndex      =   4
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "berpscanner"
            Object.ToolTipText     =   "BERP Scanner"
            ImageIndex      =   5
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "screenamecollector"
            Object.ToolTipText     =   "Screen Name Collector"
            ImageIndex      =   6
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "spammer"
            Object.ToolTipText     =   "Spammer"
            ImageIndex      =   7
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "tank"
            Object.ToolTipText     =   "Tank"
            ImageIndex      =   8
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "about"
            Object.ToolTipText     =   "About"
            ImageIndex      =   9
         EndProperty
      EndProperty
   End
   Begin VB.Menu MnuFile 
      Caption         =   "&File"
      Visible         =   0   'False
      Begin VB.Menu MnuToolBar 
         Caption         =   "MnuIndex"
         Index           =   0
      End
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public MyCancel As Boolean
Private Sub MDIForm_Load()
      For x = 1 To Toolbar1.Buttons.Count
            Load MnuToolBar(x)
            MnuToolBar(x).Visible = True
            If Toolbar1.Buttons(x).Style = tbrSeparator Then
                  MnuToolBar(x).Caption = "-"
            Else
                  MnuToolBar(x).Caption = Toolbar1.Buttons(x).ToolTipText
            End If
      Next
      MnuToolBar(0).Visible = False
      MyCancel = False
End Sub

Private Sub MDIForm_QueryUnload(Cancel As Integer, UnloadMode As Integer)
      MyCancel = True
End Sub

Private Sub MDIForm_Unload(Cancel As Integer)
      End
End Sub

Private Sub MnuToolBar_Click(Index As Integer)
      Select Case Index
            Case 1
                  'open cracker
                  Load Form3
                  Form3.Show
                  Form3.SetFocus
            Case 2
                  'open berp scanner
                  Load Form2
                  Form2.Show
                  Form2.SetFocus
            Case 3
                  'open screen name collector
                  Load Form4
                  Form4.Show
                  Form4.SetFocus
            Case 4
                  'open spammer
                  MsgBox "Look for it in version 2": Exit Sub
                  Load Form5
                  Form5.Show
                  Form5.SetFocus
            Case 5
                  'open tank
                  Load Form1
                  Form1.Show
                  Form1.SetFocus
                  Form1.Move MDIForm1.ScaleWidth - Form1.Width, 0, Form1.Width, MDIForm1.ScaleHeight
            Case 6
                  'seperator
            Case 7
                  Form6.Show , Me
      End Select
End Sub

Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
      MnuToolBar_Click (Button.Index)
End Sub
