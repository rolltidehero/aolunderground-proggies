VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form Form1 
   Caption         =   "Tank"
   ClientHeight    =   3870
   ClientLeft      =   165
   ClientTop       =   255
   ClientWidth     =   3375
   Icon            =   "tank.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   3870
   ScaleWidth      =   3375
   Begin MSComctlLib.ProgressBar ProgressBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   1
      Top             =   3615
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
      Scrolling       =   1
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   120
      Top             =   120
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin MSComctlLib.ListView ListView1 
      Height          =   2415
      Left            =   0
      TabIndex        =   0
      ToolTipText     =   "Right click for more Options"
      Top             =   0
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   4260
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
   Begin VB.Menu MnuFile 
      Caption         =   "&File"
      Visible         =   0   'False
      Begin VB.Menu MnuOpen 
         Caption         =   "&Open List"
      End
      Begin VB.Menu MnuSave 
         Caption         =   "&Save List"
      End
      Begin VB.Menu mnuline 
         Caption         =   "-"
      End
      Begin VB.Menu MnuDelete 
         Caption         =   "- Item"
      End
      Begin VB.Menu MnuAdd 
         Caption         =   "+ Item"
      End
      Begin VB.Menu mnuline1 
         Caption         =   "-"
      End
      Begin VB.Menu MnuTest 
         Caption         =   "Check Name"
      End
      Begin VB.Menu MnuAll 
         Caption         =   "Check All"
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim MyButton As Long

Private Sub Form_Load()
      On Error Resume Next
      ListView1.ColumnHeaders.Add , , "Screen Name"
      ListView1.ColumnHeaders.Add , , "Password"
      ListView1.View = lvwReport
      ListView1.FullRowSelect = True
      ListView1.ColumnHeaders(1).Width = ListView1.Width / 2 - 200
      ListView1.ColumnHeaders(2).Width = ListView1.Width / 2 - 200
      Me.Show
      Me.Move MDIForm1.ScaleWidth - Me.Width, 0, Me.Width, MDIForm1.ScaleHeight
      'Me.Move MDIForm1.ScaleWidth - Me.Width, 0, MDIForm1.ScaleWidth - 7000, MDIForm1.ScaleHeight
End Sub



Private Sub Form_Resize()
      On Error Resume Next
      If Me.Width <> 3500 Then Me.Width = 3500
      ListView1.Move 0, 0, ScaleWidth, ScaleHeight - ProgressBar1.Height
      ListView1.ColumnHeaders(1).Width = ListView1.Width / 2 - 200
      ListView1.ColumnHeaders(2).Width = ListView1.Width / 2 - 200
End Sub


Private Sub Form_Unload(Cancel As Integer)
      If MDIForm1.MyCancel = True Then
            Cancel = 0
      Else
            Cancel = 1
            Me.Visible = False
      End If
End Sub

Private Sub ListView1_Click()
      If MyButton = 2 Then
            PopupMenu MnuFile
      End If
End Sub

Private Sub ListView1_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)
      ListView1.Sorted = True
      ListView1.SortKey = ColumnHeader.Index - 1
      If ListView1.SortOrder = lvwAscending Then
            ListView1.SortOrder = lvwDescending
      Else
            ListView1.SortOrder = lvwAscending
      End If
End Sub


Private Sub ListView1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
      MyButton = Button
End Sub

Private Sub MnuAdd_Click()
      Dim X As Long, AddIt As Boolean
      Dim Data As String, NewItem As MSComctlLib.ListItem
      Do
            Data = InputBox("Please enter Requested data... ScreenName:Password", "Ultimate Cracking Utility", , (Me.Left + MDIForm1.Left + Me.Width) / 2, (Me.Top + MDIForm1.Top + Me.Height) / 2)
            If Not LCase(Replace(Data, " ", "")) = "" Then
                  AddIt = True
                  For X = 1 To ListView1.ListItems.Count
                        If LCase(Replace(ListView1.ListItems(X).Text, " ", "")) = LCase(Replace(Split(Data, ":")(0), " ", "")) Then AddIt = False
                  Next
                  If AddIt = True Then Set NewItem = ListView1.ListItems.Add(, , LCase(Replace(Split(Data, ":")(0), " ", "")))
                  NewItem.SubItems(1) = Split(Data, ":")(1)
            End If
      Loop Until Data = ""
End Sub

Private Sub MnuAll_Click()
      'test all
End Sub

Private Sub MnuDelete_Click()
      On Error GoTo errhandler
      Select Case MsgBox("Are you sure you wish to delete " & ListView1.SelectedItem.Text & "?", vbYesNo, "Ultimate Cracking Utility")
            Case vbYes
                  ListView1.ListItems.Remove ListView1.SelectedItem.Index
            Case vbNo
                  'do nothing
      End Select
      Exit Sub
errhandler:
      
End Sub

Private Sub MnuOpen_Click()
      On Error Resume Next
      Dim MyData As String, NewItem As MSComctlLib.ListItem
      CommonDialog1.FileName = ""
      CommonDialog1.ShowOpen
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = FileLen(CommonDialog1.FileName)
      Open CommonDialog1.FileName For Input As #1
            Do
                  Input #1, MyData
                  Set NewItem = ListView1.ListItems.Add(, , Split(MyData, ":")(0))
                  NewItem.SubItems(1) = Split(MyData, ":")(1)
                  ProgressBar1.Value = ProgressBar1.Value + Len(MyData) + 2
                  DoEvents
            Loop Until EOF(1)
      Close #1
      ProgressBar1.Value = 0
End Sub

Private Sub MnuSave_Click()
      On Error Resume Next
      Dim MyData As String, X As Long
      CommonDialog1.FileName = ""
      CommonDialog1.ShowSave
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = ListView1.ListItems.Count
      Open CommonDialog1.FileName For Output As #1
            For X = 1 To ListView1.ListItems.Count
                  MyData = ListView1.ListItems(X).Text & ":" & ListView1.ListItems(X).SubItems(1)
                  Print #1, MyData
                  ProgressBar1.Value = X
                  DoEvents
            Next
      Close #1
      ProgressBar1.Value = 0
End Sub

Private Sub MnuTest_Click()
      'signon selected name
End Sub
