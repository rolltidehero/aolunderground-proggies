VERSION 5.00
Begin VB.Form Form5 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Spammer"
   ClientHeight    =   2175
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   2835
   Icon            =   "spammer.frx":0000
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   2175
   ScaleWidth      =   2835
   Begin VB.Label Label1 
      Caption         =   "not yet complete"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1335
   End
End
Attribute VB_Name = "Form5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
      'Me.Move 4000, MDIForm1.ScaleHeight - Me.Height
End Sub

Private Sub Form_Unload(Cancel As Integer)
      If MDIForm1.MyCancel = True Then
            Cancel = 0
      Else
            Cancel = 1
            Me.Visible = False
      End If
End Sub
