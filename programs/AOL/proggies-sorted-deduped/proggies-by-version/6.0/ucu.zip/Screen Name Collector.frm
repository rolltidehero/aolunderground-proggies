VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form Form4 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "SN Collector"
   ClientHeight    =   4140
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   2955
   Icon            =   "Screen Name Collector.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   4140
   ScaleWidth      =   2955
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   2400
      Top             =   3360
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Command8 
      Caption         =   "Load ABC's"
      Height          =   375
      Left            =   1800
      TabIndex        =   12
      Top             =   0
      Width           =   1095
   End
   Begin VB.Frame Frame1 
      Caption         =   "Search phrases"
      Height          =   975
      Left            =   0
      TabIndex        =   5
      Top             =   480
      Width           =   2895
      Begin VB.ComboBox Combo1 
         Height          =   315
         Left            =   120
         Style           =   2  'Dropdown List
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   240
         Width           =   2655
      End
      Begin VB.CommandButton Command6 
         Caption         =   "Load"
         Height          =   255
         Left            =   2160
         TabIndex        =   6
         TabStop         =   0   'False
         ToolTipText     =   "Load List"
         Top             =   600
         Width           =   615
      End
      Begin VB.CommandButton Command5 
         Caption         =   "Save"
         Height          =   255
         Left            =   1560
         TabIndex        =   7
         TabStop         =   0   'False
         ToolTipText     =   "Save List"
         Top             =   600
         Width           =   615
      End
      Begin VB.CommandButton Command7 
         Caption         =   "Clear"
         Height          =   255
         Left            =   720
         TabIndex        =   9
         TabStop         =   0   'False
         ToolTipText     =   "Clear List"
         Top             =   600
         Width           =   735
      End
      Begin VB.CommandButton Command4 
         Caption         =   "-"
         Height          =   255
         Left            =   360
         TabIndex        =   10
         TabStop         =   0   'False
         ToolTipText     =   "Remove Item"
         Top             =   600
         Width           =   255
      End
      Begin VB.CommandButton Command1 
         Caption         =   "+"
         Height          =   255
         Left            =   120
         TabIndex        =   11
         TabStop         =   0   'False
         ToolTipText     =   "Add Item"
         Top             =   600
         Width           =   255
      End
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Export to..."
      Height          =   375
      Left            =   720
      TabIndex        =   1
      Top             =   0
      Width           =   1095
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Collect"
      Height          =   375
      Left            =   0
      TabIndex        =   2
      Top             =   0
      Width           =   735
   End
   Begin VB.ListBox List1 
      Height          =   2010
      Left            =   0
      Sorted          =   -1  'True
      TabIndex        =   0
      Top             =   1560
      Width           =   2895
   End
   Begin MSComctlLib.ProgressBar ProgressBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   3
      Top             =   3630
      Width           =   2955
      _ExtentX        =   5212
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
      Scrolling       =   1
   End
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   4
      Top             =   3885
      Width           =   2955
      _ExtentX        =   5212
      _ExtentY        =   450
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   2
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   2566
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   2566
         EndProperty
      EndProperty
   End
   Begin VB.Menu MnuFile 
      Caption         =   "&File"
      Visible         =   0   'False
      Begin VB.Menu MnuCracker 
         Caption         =   "&Password Cracker"
      End
      Begin VB.Menu MnuSpammer 
         Caption         =   "&Spammer"
      End
      Begin VB.Menu MnuSave 
         Caption         =   "S&ave..."
      End
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public StopIt As Boolean


Private Sub Command1_Click()
      Dim x As Long, AddIT As Boolean
      Dim Data As String
      Do
            Data = InputBox("Please enter a " & Mid(Frame1.Caption, 1, Len(Frame1.Caption) - 1), "Ultimate Cracking Utility", , (Me.Left + MDIForm1.Left + Me.Width) / 2, (Me.Top + MDIForm1.Top + Me.Height) / 2)
            If Not LCase(Replace(Data, " ", "")) = "" Then
                  AddIT = True
                  For x = 0 To Combo1.ListCount - 1
                        If LCase(Replace(Combo1.List(x), " ", "")) = LCase(Replace(Data, " ", "")) Then AddIT = False
                  Next
                  If AddIT = True Then Combo1.AddItem LCase(Replace(Data, " ", ""))
            End If
      Loop Until Data = ""
      If Combo1.ListCount > 0 Then Combo1.ListIndex = 0
End Sub

Private Sub Command2_Click()
      PopupMenu MnuFile
End Sub

Private Sub Command3_Click()
      Dim AOLList As Long, AOLChild As Long, CurIndex As Long
      Dim x As Long, AOLIcon As Long
      If Combo1.ListCount = 0 Then Command8_Click
      Select Case Command3.Caption
            Case "Collect"
                  Command3.Caption = "Stop"
                  StopIt = False
                  CurIndex = 0
                  Do
                        CloseWindow FindMDSR
                        CloseWindow FindMD
                        DoEvents
                        KeyWord "member directory"
                        Do
                              If StopIt = True Then Exit Sub
                              DoEvents
                        Loop While FindMD = 0
                        SetMDSearchField Combo1.List(CurIndex)
                        Do
                              If StopIt = True Then Exit Sub
                              DoEvents
                        Loop Until Not FindMDSR = 0
                        'click more
                        'AOLChild = FindMDSR
                        'AOLIcon = FindWindowEx(AOLChild, 0, "_AOL_Icon", vbNullString)
                        'For x = 0 To 3
                        '      TimeOut 1
                        '      Do
                        '            DoEvents
                        '      Loop Until IsWindowEnabled(AOLIcon) = 1
                        '      DoEvents
                        '      SendMessage AOLIcon, WM_CHAR, 13, 0
                        'Next
                        AOLChild = FindMDSR
                        AOLList = FindWindowEx(AOLChild, 0, "_AOL_Listbox", vbNullString)
                        AddAOLListToVBListMD List1, AOLList
                        StatusBar1.Panels(1).Text = List1.ListCount
                        StatusBar1.Panels(2).Text = "Pauseing 5 Seconds"
                        CloseWindow FindMDSR
                        CloseWindow FindMD
                        CurIndex = CurIndex + 1
                        If CurIndex = Combo1.ListCount Then Command3_Click
                        TimeOut 5
                  Loop Until StopIt = True
            Case "Stop"
                  StopIt = True
                  Command3.Caption = "Collect"
      End Select
End Sub


Private Sub Command4_Click()
      If Combo1.ListIndex < 0 Then Exit Sub
      Select Case MsgBox("Are you sure you wish to delete " & Combo1.Text, vbYesNo, "Ultimate Cracking Utility")
            Case vbYes
                  Combo1.RemoveItem Combo1.ListIndex
            Case vbNo
                  'do nothing
      End Select
      If Combo1.ListCount > 0 Then Combo1.ListIndex = 0
End Sub

Private Sub Command5_Click()
      On Error Resume Next
      Dim x As Long
      CommonDialog1.FileName = ""
      CommonDialog1.ShowSave
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = Combo1.ListCount - 1
      StatusBar1.Panels(2).Text = "Saving..."
      Open CommonDialog1.FileName For Output As #1
            For x = 0 To Combo1.ListCount - 1
                  Print #1, Combo1.List(x)
                  ProgressBar1.Value = x
                  DoEvents
            Next
      Close #1
      ProgressBar1.Value = 0
      StatusBar1.Panels(2).Text = "Complete"
End Sub

Private Sub Command6_Click()
      On Error Resume Next
      Dim x As Long, Data As String, AddIT As Boolean
      CommonDialog1.FileName = ""
      CommonDialog1.ShowOpen
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = FileLen(CommonDialog1.FileName)
      StatusBar1.Panels(2).Text = "Loading..."
      Open CommonDialog1.FileName For Input As #1
            Do
                  Input #1, Data
                  AddIT = True
                  For x = 0 To Combo1.ListCount - 1
                        If LCase(Replace(Data, " ", "")) = LCase(Replace(Combo1.List(x), " ", "")) Then AddIT = False
                  Next
                  If AddIT = True Then Combo1.AddItem Data
                  DoEvents
                  ProgressBar1.Value = ProgressBar1.Value + Len(Data) + 2
            Loop Until EOF(1)
      Close #1
      ProgressBar1.Value = 0
      StatusBar1.Panels(2).Text = "Complete"
      If Combo1.ListCount > 0 Then Combo1.ListIndex = 0

End Sub

Private Sub Command7_Click()
      If Combo1.ListCount = 0 Then Exit Sub
      Select Case MsgBox("Are you sure you want to clear the " & Frame1.Caption & " list?", vbYesNo)
            Case vbYes
                  Combo1.Clear
            Case vbNo
                  'do nothing
      End Select
End Sub

Private Sub Command8_Click()
      Dim x As Long, CurChar As String, AddIT As Boolean, y As Long
      CurChar = "a"
      For x = 1 To 26
            AddIT = True
            For y = 0 To Combo1.ListCount - 1
                  If LCase(Replace(CurChar & CurChar & CurChar, " ", "")) = LCase(Replace(Combo1.List(y), " ", "")) Then AddIT = False
            Next
            If AddIT = True Then Combo1.AddItem CurChar & CurChar & CurChar
            CurChar = Chr(Asc(CurChar) + 1)
      Next
End Sub



Private Sub Form_Unload(Cancel As Integer)
      If MDIForm1.MyCancel = True Then
            Cancel = 0
      Else
            Cancel = 1
            Me.Visible = False
      End If
      StopIt = True
End Sub

Private Sub MnuCracker_Click()
      Dim x As Long, y As Long, AddIT As Boolean
      Form3.Show
      Form3.SetFocus
      For x = 0 To List1.ListCount - 1
            AddIT = True
            For y = 0 To Form3.Combo1(0).ListCount - 1
                  If Form3.Combo1(0).List(y) = List1.List(x) Then AddIT = False
            Next
            If AddIT = True Then Form3.Combo1(0).AddItem List1.List(x)
      Next
End Sub

Private Sub Option1_Click(Index As Integer)

End Sub

Private Sub MnuSave_Click()
      On Error Resume Next
      Dim x As Long
      CommonDialog1.FileName = ""
      CommonDialog1.ShowSave
      If CommonDialog1.FileName = "" Then Exit Sub
      ProgressBar1.Max = Combo1.ListCount - 1
      StatusBar1.Panels(2).Text = "Saving..."
      Open CommonDialog1.FileName For Output As #1
            For x = 0 To List1.ListCount - 1
                  Print #1, List1.List(x)
                  ProgressBar1.Value = x
                  DoEvents
            Next
      Close #1
      ProgressBar1.Value = 0
      StatusBar1.Panels(2).Text = "Complete"
End Sub


