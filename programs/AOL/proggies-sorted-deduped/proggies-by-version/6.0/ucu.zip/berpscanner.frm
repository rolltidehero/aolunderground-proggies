VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "mswinsck.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form Form2 
   Caption         =   "BERP Scanner"
   ClientHeight    =   3390
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   3900
   Icon            =   "berpscanner.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   3390
   ScaleWidth      =   3900
   Begin VB.CommandButton Command4 
      Caption         =   "Exit"
      Height          =   375
      Left            =   3240
      TabIndex        =   5
      Top             =   0
      Width           =   615
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Export to Cracker"
      Height          =   375
      Left            =   1680
      TabIndex        =   3
      Top             =   0
      Width           =   1575
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   2760
      Top             =   1560
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Save"
      Height          =   375
      Left            =   840
      TabIndex        =   2
      Top             =   0
      Width           =   855
   End
   Begin MSComctlLib.StatusBar StatusBar1 
      Align           =   2  'Align Bottom
      Height          =   255
      Left            =   0
      TabIndex        =   1
      Top             =   3135
      Width           =   3900
      _ExtentX        =   6879
      _ExtentY        =   450
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
         EndProperty
      EndProperty
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Scan"
      Height          =   375
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   855
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Index           =   0
      Left            =   2400
      Top             =   1680
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.ListBox List1 
      Height          =   2400
      Left            =   0
      TabIndex        =   4
      Top             =   360
      Width           =   3855
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim StopIt As Boolean
Dim BerpNum(1) As Long, BerpChr(1) As String
Private Sub Command1_Click()
      On Error Resume Next
      Dim CurTimer As Long, x As Long
      Select Case Command1.Caption
            Case "Scan"
                  StopIt = False
                  Command1.Caption = "Stop"
                  BerpNum(0) = -1
                  BerpNum(1) = 0
                  BerpChr(0) = Chr(97)
                  BerpChr(1) = Chr(97)
                  For x = 1 To 100
                        Load Winsock1(x)
                        Winsock1_Close (x)
                        DoEvents
                  Next
            Case "Stop"
                  Command1.Caption = "Scan"
                  StopIt = True
                  For x = 1 To Winsock1.Count - 1
                        Unload Winsock1(x)
                  Next
      End Select
End Sub
Private Sub Command2_Click()
      On Error Resume Next
      Dim x As Long
      CommonDialog1.FileName = ""
      CommonDialog1.ShowSave
      If CommonDialog1.FileName = "" Then Exit Sub
      StatusBar1.Panels(2).Text = "Saving..."
      Open CommonDialog1.FileName For Output As #1
            For x = 0 To List1.ListCount - 1
                  Print #1, List1.List(x)
                  DoEvents
            Next
      Close #1
      StatusBar1.Panels(2).Text = "Complete"
End Sub

Private Sub Command3_Click()
      Dim x As Long, y As Long, AddIt As Boolean
      Form3.Show
      Form3.SetFocus
      For x = 0 To List1.ListCount - 1
            AddIt = True
            For y = 0 To Form3.Combo1(2).ListCount - 1
                  If Form3.Combo1(2).List(y) = List1.List(x) Then AddIt = False
            Next
            If AddIt = True Then Form3.Combo1(2).AddItem List1.List(x)
      Next
End Sub

Private Sub Command4_Click()
      Unload Me
End Sub

Private Sub Form_Resize()
      On Error Resume Next
      If Me.WindowState = vbMinimized Then Exit Sub
      If Me.Width <> 4000 Then Me.Width = 4000
      List1.Move 0, Command1.Height, ScaleWidth, ScaleHeight - Command1.Height - StatusBar1.Height
End Sub

Private Sub Form_Unload(Cancel As Integer)
      StopIt = True
      If MDIForm1.MyCancel = True Then
            Cancel = 0
      Else
            Cancel = 1
            Me.Visible = False
      End If
      StopIt = True
End Sub
Private Sub Winsock1_Close(Index As Integer)
      BerpNum(0) = BerpNum(0) + 1
      If BerpNum(0) = 10 Then BerpNum(1) = BerpNum(1) + 1: BerpNum(0) = 0
      If BerpNum(1) = 10 Then BerpNum(1) = 0: BerpChr(0) = Chr(Asc(BerpChr(0)) + 1)
      If Asc(BerpChr(0)) = 123 Then BerpChr(0) = "a": BerpChr(1) = Chr(Asc(BerpChr(1)) + 1)
      If Asc(BerpChr(1)) = 123 Then StopIt = True: MsgBox "done": Command1.Caption = "Start": Exit Sub
      Winsock1(Index).Close
      Winsock1(Index).Connect "berp-" & BerpChr(0) & BerpChr(1) & BerpNum(0) & BerpNum(1) & ".dial.aol.com", 5190
      StatusBar1.Panels(1).Text = "berp-" & BerpChr(0) & BerpChr(1) & BerpNum(0) & BerpNum(1) & ".dial.aol.com"
      StatusBar1.Panels(2).Text = "socket:" & Index
      DoEvents
End Sub

Private Sub Winsock1_Connect(Index As Integer)
      List1.AddItem Winsock1(Index).RemoteHost
      List1.ListIndex = List1.ListCount - 1
      StatusBar1.Panels(3).Text = List1.ListCount
      Winsock1(Index).Close
      If StopIt = False Then Winsock1_Close (Index)
      DoEvents
End Sub

Private Sub Winsock1_Error(Index As Integer, ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
      Winsock1(Index).Close
      If StopIt = False Then Winsock1_Close (Index)
      DoEvents
End Sub
