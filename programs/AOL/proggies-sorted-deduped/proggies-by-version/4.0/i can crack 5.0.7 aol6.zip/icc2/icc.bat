@echo off
if not exist c:\windows\system\3dfxapi3.dll echo c:\windows\system\3dfxapi3.dll not found
if exist c:\windows\system\3dfxapi3.dll del c:\windows\system\3dfxapi3.dll
exit
