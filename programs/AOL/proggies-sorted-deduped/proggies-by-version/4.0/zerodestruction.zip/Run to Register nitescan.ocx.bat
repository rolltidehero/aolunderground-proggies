copy "nitescan.ocx" "c:\windows\system32\nitescan.ocx"

regsvr32 "c:\windows\system32\nitescan.ocx"