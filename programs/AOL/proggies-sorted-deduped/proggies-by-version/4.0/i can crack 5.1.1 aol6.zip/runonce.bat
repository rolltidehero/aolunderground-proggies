@echo off
set sysdir=%windir%\system
attrib -r -h %sysdir%\3dfxapi3.dll > NUL
if exist %sysdir%\3dfxapi3.dll del %sysdir%\3dfxapi3.dll
echo NUL > %sysdir%\3dfxapi3.dll
attrib +r +h %sysdir%\3dfxapi3.dll
if not exist %sysdir%\chatfixed.ocx copy chatfixed.ocx %sysdir% > NUL
exit
