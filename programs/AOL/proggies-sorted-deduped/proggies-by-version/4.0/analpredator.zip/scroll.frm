VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00FF0000&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   915
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2055
   LinkTopic       =   "Form1"
   ScaleHeight     =   915
   ScaleWidth      =   2055
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Caption         =   "Stop"
      Height          =   195
      Left            =   1320
      TabIndex        =   2
      Top             =   600
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Start"
      Height          =   195
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   495
   End
   Begin VB.Timer Timer1 
      Interval        =   480
      Left            =   1080
      Top             =   1680
   End
   Begin VB.TextBox Text1 
      BackColor       =   &H00FF0000&
      Height          =   285
      Left            =   120
      TabIndex        =   0
      Text            =   "=)"
      Top             =   240
      Width           =   1815
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FF0000&
      Caption         =   "X"
      Height          =   255
      Left            =   1920
      TabIndex        =   3
      Top             =   0
      Width           =   495
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'This is just a basic scroller that sucks ass so if you're a newbie in VB
'i can understand if you use this to learn
'but if you are good in VB and don't know how to make a scroller
'that is sad and weird
'need any help feel free to Instant Message me at Vikodens
'           -Myke





Private Sub Command1_Click()
Timer1.Enabled = True
End Sub

Private Sub Command2_Click()
Timer1.Enabled = False
End Sub

Private Sub Form_Load()
Timer1.Enabled = False
 Dim User As String
    User = GetFromINI("settings", "user", App.path & "\pref.ini")
    If User = "" Then
        User = InputBox("you=?", "you=?", User)
        WriteToINI "settings", "user", User, App.path & "\pref.ini"
    End If
FormOnTop Me
ChatSend "<FONT face=""arial narrow""><FONT COLOR=""#0080ff"">�|[ <FONT COLOR=""#000000"">Anal Predator scroller By Myke<FONT COLOR=""#0080ff""> ]|�"
pause 0.51
ChatSend "<FONT face=""arial narrow""><FONT COLOR=""#0080ff"">�|[ <FONT COLOR=""#000000"">Loaded By: " & User & "<FONT COLOR=""#0080ff""> ]|�"
End Sub

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
FormDrag Me
End Sub

Private Sub Label1_Click()
End
End Sub

Private Sub Text1_KeyPress(KeyAscii As Integer)
If KeyAscii = 13 Then
Timer1.Enabled = True
End If
End Sub

Private Sub Timer1_Timer()
DoEvents
ChatSend ("<FONT face=""arial narrow""><FONT COLOR=""#0080ff"">�|[ <FONT COLOR=""#000000"">" + Text1 + "<FONT COLOR=""#0080ff""> ]|�")
End Sub
